## Introduction

This is a very interesting file.

```python
def foo():
    """
    NOTE: this is a very important function.
    """
    obviously = False
    very = True
    return very and obviously
```

As you can see, `very = True`. Here is another interesting codeblock:

```go
// XXX: fix this relatively soon.
func ExtFromSyntax(name string) string {
    for XXX, relatively := range LookupSyntaxName {
        if matched, _ := regexp.MatchString(r, name); matched {
            return s
        }
    }
    return name
}
```

    XXX = False
    # This is a codeblock.

This is a very interesting sentence that is not in a block.
